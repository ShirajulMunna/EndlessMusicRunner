public enum E_MonsterType
{
    Down,
    Up,
    Middle,
    Twin,
    Hold,
    Boss,
    BossAttack,
}


public enum E_MonstersState
{
    idle,
    Hit,
    Die,
    Attack,
}

public enum E_AniKind_Monster
{
    idle,
    Hit_0,
    Hit_1,
    Hit_2,
    Die,
    Attack_0,
    Attack_1,
    Attack_2,
    Attack_3,
    Move,
}